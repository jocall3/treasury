import "core-js/stable";
import "regenerator-runtime/runtime";
import "whatwg-fetch";

import "../src/app";
import "../src/common/stylesheets/application.scss";

require.context("../images", true);
