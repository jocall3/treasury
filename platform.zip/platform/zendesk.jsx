/* eslint-disable no-undef */
export function openZendeskChat() {
  if (zE) {
    zE(() => zE.activate());
  }
}
